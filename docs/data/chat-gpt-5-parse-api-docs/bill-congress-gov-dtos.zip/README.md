# Congress.gov DTOs (TypeScript)

DTO interfaces and property enums mirroring the Congress.gov v3 API (subset: bills, details, and actions).

- One file per entity, named after the entity.
- Each interface uses an accompanying `*PropEnum` to allow safe mapped access like the example you provided.

## Install

Copy the folder into your project (e.g., `src/models/congress/`).

## Usage

```ts
import { IBill, BillPropEnum } from "./Bill.model";

const b: IBill = {
  [BillPropEnum.congress]: 118,
  [BillPropEnum.number]: "1",
  [BillPropEnum.originChamber]: "House",
  [BillPropEnum.originChamberCode]: "H",
  [BillPropEnum.title]: "Example",
  [BillPropEnum.type]: "hr",
  [BillPropEnum.updateDate]: "2024-01-01",
  [BillPropEnum.latestAction]: { actionDate: "2024-01-02", text: "Introduced." },
  [BillPropEnum.url]: "https://api.congress.gov/v3/bill/118/hr/1?format=json",
};
```

> Note: Field sets are based on sample responses from the official Swagger page. You may extend them if your application needs more endpoints.
