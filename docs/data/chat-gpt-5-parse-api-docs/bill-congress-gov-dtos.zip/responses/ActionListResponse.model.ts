import type { IAction } from "../bill-details/Action.model";

export enum ActionListResponsePropEnum {
  actions = "actions",
}

export interface IActionListResponse {
  [ActionListResponsePropEnum.actions]: IAction[];
}
