import type { IBillDetails } from "../bill-details/BillDetails.model";

export enum BillDetailsResponsePropEnum {
  bill = "bill",
}

export interface IBillDetailsResponse {
  [BillDetailsResponsePropEnum.bill]: IBillDetails;
}
