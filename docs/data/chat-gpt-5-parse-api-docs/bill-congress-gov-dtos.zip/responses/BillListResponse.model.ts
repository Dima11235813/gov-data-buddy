import type { IBill } from "../Bill.model";

export enum BillListResponsePropEnum {
  bills = "bills",
}

export interface IBillListResponse {
  [BillListResponsePropEnum.bills]: IBill[];
}
