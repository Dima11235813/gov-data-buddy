import type { ILatestAction } from "./LatestAction.model";

export enum BillPropEnum {
  congress = "congress",
  number = "number",
  originChamber = "originChamber",
  originChamberCode = "originChamberCode",
  title = "title",
  type = "type",
  updateDate = "updateDate",
  updateDateIncludingText = "updateDateIncludingText",
  latestAction = "latestAction",
  url = "url",
}

export interface IBill {
  [BillPropEnum.congress]: number;
  [BillPropEnum.number]: string;
  [BillPropEnum.originChamber]: string;
  [BillPropEnum.originChamberCode]: string;
  [BillPropEnum.title]: string;
  [BillPropEnum.type]: string; // hr | s | hjres | sjres | hconres | sconres | hres | sres
  [BillPropEnum.updateDate]: string; // ISO timestamp or YYYY-MM-DD
  [BillPropEnum.updateDateIncludingText]?: string; // ISO timestamp
  [BillPropEnum.latestAction]: ILatestAction;
  [BillPropEnum.url]: string; // API item URL
}
