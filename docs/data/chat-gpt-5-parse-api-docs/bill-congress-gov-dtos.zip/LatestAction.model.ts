export enum LatestActionPropEnum {
  actionDate = "actionDate",
  text = "text",
}

export interface ILatestAction {
  [LatestActionPropEnum.actionDate]: string; // YYYY-MM-DD
  [LatestActionPropEnum.text]: string;
}
