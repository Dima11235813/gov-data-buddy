export enum CountLinkPropEnum {
  count = "count",
  url = "url",
}

export interface ICountLink {
  [CountLinkPropEnum.count]: number;
  [CountLinkPropEnum.url]: string;
}
