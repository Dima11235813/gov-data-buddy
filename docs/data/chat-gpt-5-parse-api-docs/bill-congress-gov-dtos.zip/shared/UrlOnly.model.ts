export enum UrlOnlyPropEnum {
  url = "url",
}
export interface IUrlOnly {
  [UrlOnlyPropEnum.url]: string;
}
