export enum SourceSystemPropEnum {
  code = "code",
  name = "name",
}
export interface ISourceSystem {
  [SourceSystemPropEnum.code]: number;
  [SourceSystemPropEnum.name]: string;
}
