export enum PolicyAreaPropEnum {
  name = "name",
}
export interface IPolicyArea {
  [PolicyAreaPropEnum.name]: string;
}
