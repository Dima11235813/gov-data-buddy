export enum SponsorPropEnum {
  bioguideId = "bioguideId",
  district = "district",
  firstName = "firstName",
  fullName = "fullName",
  isByRequest = "isByRequest",
  lastName = "lastName",
  middleName = "middleName",
  party = "party",
  state = "state",
  url = "url",
}

export interface ISponsor {
  [SponsorPropEnum.bioguideId]: string;
  [SponsorPropEnum.district]?: number;
  [SponsorPropEnum.firstName]?: string;
  [SponsorPropEnum.fullName]: string;
  [SponsorPropEnum.isByRequest]?: string; // "Y" | "N"
  [SponsorPropEnum.lastName]?: string;
  [SponsorPropEnum.middleName]?: string;
  [SponsorPropEnum.party]?: string;
  [SponsorPropEnum.state]?: string;
  [SponsorPropEnum.url]?: string; // member API URL
}
