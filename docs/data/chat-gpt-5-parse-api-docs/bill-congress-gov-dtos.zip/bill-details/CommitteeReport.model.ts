export enum CommitteeReportPropEnum {
  citation = "citation",
  url = "url",
}
export interface ICommitteeReport {
  [CommitteeReportPropEnum.citation]: string;
  [CommitteeReportPropEnum.url]: string;
}
