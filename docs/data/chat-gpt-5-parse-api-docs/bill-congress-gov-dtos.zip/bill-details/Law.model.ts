export enum LawPropEnum {
  number = "number",
  type = "type",
}
export interface ILaw {
  [LawPropEnum.number]: string; // e.g., "117-108"
  [LawPropEnum.type]: string;   // e.g., "Public Law"
}
