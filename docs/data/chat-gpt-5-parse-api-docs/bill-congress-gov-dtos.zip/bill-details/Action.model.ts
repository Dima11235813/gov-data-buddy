import type { ISourceSystem } from "./SourceSystem.model";

export enum ActionPropEnum {
  actionCode = "actionCode",
  actionDate = "actionDate",
  sourceSystem = "sourceSystem",
  text = "text",
  type = "type",
}

export interface IAction {
  [ActionPropEnum.actionCode]?: string;
  [ActionPropEnum.actionDate]: string; // YYYY-MM-DD
  [ActionPropEnum.sourceSystem]?: ISourceSystem;
  [ActionPropEnum.text]: string;
  [ActionPropEnum.type]?: string;
}
