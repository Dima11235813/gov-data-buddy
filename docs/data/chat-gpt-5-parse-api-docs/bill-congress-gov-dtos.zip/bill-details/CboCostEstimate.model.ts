export enum CboCostEstimatePropEnum {
  description = "description",
  pubDate = "pubDate",
  title = "title",
  url = "url",
}
export interface ICboCostEstimate {
  [CboCostEstimatePropEnum.description]: string;
  [CboCostEstimatePropEnum.pubDate]: string; // ISO timestamp
  [CboCostEstimatePropEnum.title]: string;
  [CboCostEstimatePropEnum.url]: string;
}
