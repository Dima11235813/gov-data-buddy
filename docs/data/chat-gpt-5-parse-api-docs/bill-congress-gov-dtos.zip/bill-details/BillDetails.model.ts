import type { ICountLink } from "../shared/CountLink.model";
import type { ILatestAction } from "../LatestAction.model";
import type { ICboCostEstimate } from "./CboCostEstimate.model";
import type { ICommitteeReport } from "./CommitteeReport.model";
import type { ILaw } from "./Law.model";
import type { IPolicyArea } from "./PolicyArea.model";
import type { ISponsor } from "./Sponsor.model";

export enum BillDetailsPropEnum {
  actions = "actions",
  amendments = "amendments",
  cboCostEstimates = "cboCostEstimates",
  committeeReports = "committeeReports",
  committees = "committees",
  congress = "congress",
  constitutionalAuthorityStatementText = "constitutionalAuthorityStatementText",
  cosponsors = "cosponsors",
  introducedDate = "introducedDate",
  latestAction = "latestAction",
  laws = "laws",
  legislationUrl = "legislationUrl",
  number = "number",
  originChamber = "originChamber",
  policyArea = "policyArea",
  relatedBills = "relatedBills",
  sponsors = "sponsors",
  subjects = "subjects",
  summaries = "summaries",
  textVersions = "textVersions",
  title = "title",
  titles = "titles",
  type = "type",
  updateDate = "updateDate",
  updateDateIncludingText = "updateDateIncludingText",
}

export interface IBillDetails {
  [BillDetailsPropEnum.actions]: ICountLink;
  [BillDetailsPropEnum.amendments]: ICountLink;
  [BillDetailsPropEnum.cboCostEstimates]: ICboCostEstimate[];
  [BillDetailsPropEnum.committeeReports]: ICommitteeReport[];
  [BillDetailsPropEnum.committees]: ICountLink;
  [BillDetailsPropEnum.congress]: number;
  [BillDetailsPropEnum.constitutionalAuthorityStatementText]?: string;
  [BillDetailsPropEnum.cosponsors]: ICountLink & { countIncludingWithdrawnCosponsors?: number };
  [BillDetailsPropEnum.introducedDate]: string; // YYYY-MM-DD
  [BillDetailsPropEnum.latestAction]: ILatestAction;
  [BillDetailsPropEnum.laws]?: ILaw[];
  [BillDetailsPropEnum.legislationUrl]?: string; // congress.gov URL
  [BillDetailsPropEnum.number]: string;
  [BillDetailsPropEnum.originChamber]: string;
  [BillDetailsPropEnum.policyArea]?: IPolicyArea;
  [BillDetailsPropEnum.relatedBills]: ICountLink;
  [BillDetailsPropEnum.sponsors]: ISponsor[];
  [BillDetailsPropEnum.subjects]: ICountLink;
  [BillDetailsPropEnum.summaries]: ICountLink;
  [BillDetailsPropEnum.textVersions]: ICountLink;
  [BillDetailsPropEnum.title]: string;
  [BillDetailsPropEnum.titles]: ICountLink;
  [BillDetailsPropEnum.type]: string;
  [BillDetailsPropEnum.updateDate]: string; // ISO
  [BillDetailsPropEnum.updateDateIncludingText]?: string; // ISO
}
